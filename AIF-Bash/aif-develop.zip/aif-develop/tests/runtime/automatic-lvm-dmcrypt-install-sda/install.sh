#!/bin/sh
aif -p automatic -c /usr/share/aif/tests/runtime/automatic-lvm-dmcrypt-install-sda/profile -d