#!/bin/sh
aif -p automatic -c /usr/share/aif/tests/runtime/automatic-dmcrypt-lvm-install-sda/profile -d