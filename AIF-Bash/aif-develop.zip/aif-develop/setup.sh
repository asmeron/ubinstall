aif -p interactive
